package ut.ee.cs.mirtasoundrecundsave

import android.Manifest
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

import android.app.ProgressDialog
import android.content.ContentValues
import android.content.DialogInterface
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast

import com.google.android.gms.tasks.OnFailureListener
import com.google.android.gms.tasks.OnSuccessListener
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.UploadTask

import java.io.File
import java.io.IOException
import java.util.UUID

import android.Manifest.permission.RECORD_AUDIO
import android.Manifest.permission.WRITE_EXTERNAL_STORAGE
import android.content.Intent
import android.os.Handler
import android.view.GestureDetector
import android.view.MotionEvent
import android.widget.ImageView
import androidx.core.view.GestureDetectorCompat
import com.google.android.gms.common.util.CollectionUtils.listOf
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.IgnoreExtraProperties
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {



    val rock = R.drawable.c3
    val paper = R.drawable.g6
    val scis = R.drawable.e5
    var wins:Int = 0
    var loser:Int = 0
    var draws:Int = 0



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        fun visi(){

            your_choise.visibility=View.VISIBLE
            app_choise.visibility=View.VISIBLE

        }



        buttonrock.setOnClickListener {
            visi()

            val list = listOf(paper,rock,scis)


            val rand = list.random()

            imageView2.setImageResource(R.drawable.c3)
            image_you_ch.setImageResource(rand)
            if (rand == rock){
                draws=draws+1
                drawed.text = "Draws: $draws"


            }
            else if(rand == paper){


                loser = loser+1
                lose.text = "Lose: $loser"

                imageView2.setImageResource(R.drawable.clipart89105)
                justplay.setImageResource(R.drawable.loser)
            }
            else if(rand == scis){


                wins=wins+1
                victory.text = "Wins: $wins"
                imageView2.setImageResource(R.drawable.clipart94960)
                justplay.setImageResource(R.drawable.vicotryismine)


            }
        }

        button2.setOnClickListener {

       visi()

            val list = listOf(paper,rock,scis)


            val rand = list.random()

            imageView2.setImageResource(R.drawable.g6)
            image_you_ch.setImageResource(rand)
            if (rand == paper){
                draws=draws+1
                drawed.text = "Draws: $draws"


            }
            else if(rand == scis){


                loser = loser+1
                lose.text = "Lose: $loser"

                imageView2.setImageResource(R.drawable.download)
                justplay.setImageResource(R.drawable.loser)
            }
            else if(rand == rock){


                wins=wins+1
                victory.text = "Wins: $wins"
                imageView2.setImageResource(R.drawable.rff6)
                justplay.setImageResource(R.drawable.vicotryismine)



            }
        }
        button3.setOnClickListener {
            visi()

            val list = listOf(paper,rock,scis)


            val rand = list.random()

            imageView2.setImageResource(R.drawable.e5)
            image_you_ch.setImageResource(rand)
            if (rand == scis){
                draws=draws+1
                drawed.text = "Draws: $draws"


            }
            else if(rand == rock){


                loser = loser+1
                lose.text = "Lose: $loser"

                imageView2.setImageResource(R.drawable.b2)
                justplay.setImageResource(R.drawable.loser)
            }
            else if(rand == paper){


                wins=wins+1
                victory.text = "Wins: $wins"
                imageView2.setImageResource(R.drawable.d4)
                justplay.setImageResource(R.drawable.vicotryismine)


            }
        }



        when {
            ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    !== PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    !== PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    !== PackageManager.PERMISSION_GRANTED
            -> {
                ActivityCompat.requestPermissions( this, arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE), 1 )






            }
        }


          Handler().postDelayed({



              val intent = Intent(this, activityx::class.java)


              startActivity(intent)
          },10000)














    }














}
